import { NextResponse } from 'next/server';

const SERVERS = [
  { id: 1, name: 'NF.CREW EU', ip: 'play.nfcrew.eu', map: 'ns2_map', players: 16, maxPlayers: 32 },
  { id: 2, name: 'NF.CREW US', ip: 'play.nfcrew.us', map: 'ns2_map2', players: 8, maxPlayers: 32 }
];

export async function GET() {
  return NextResponse.json(SERVERS);
}
