import React from 'react'

export default function About() {
  return (
    <div className="max-w-4xl mx-auto px-6 py-12">
      <h2 className="text-3xl font-bold mb-4">About NF.CREW</h2>
      <p className="text-white/80">NF.CREW is a game-focused clan inspired by tactical sci-fi gameplay. This starter Next.js site uses your artwork and assets to create a modern presence.</p>
    </div>
  )
}
