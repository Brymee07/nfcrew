import React from 'react'

export default function Servers() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <h2 className="text-3xl font-bold mb-4">Servers</h2>
      <p className="text-white/80">Server list will be shown here. Example API route: /api/servers</p>
    </div>
  )
}
