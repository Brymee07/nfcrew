import React from 'react'

export default function Forum() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <h2 className="text-3xl font-bold mb-4">Forum</h2>
      <p className="text-white/80">Integrate with Discourse or build a simple threads UI backed by your DB.</p>
    </div>
  )
}
