import React from 'react'

export default function Home() {
  return (
    <section className="relative">
      <div className="hero h-[520px] bg-cover bg-center" style={{backgroundImage: 'url(/images/splash.jpg)'}}>
        <div className="bg-gradient-to-b from-black/25 via-black/40 to-black/70 h-full flex items-center">
          <div className="max-w-6xl mx-auto px-6 text-left">
            <div className="max-w-2xl">
              <h2 className="text-5xl font-extrabold text-nfblue">NF.CREW</h2>
              <p className="mt-4 text-lg text-white/80">Net Fraggers Crew — realistic, tactical, worldwide</p>
              <div className="mt-6 flex gap-4">
                <a className="px-5 py-3 rounded-md bg-nfblue text-black font-semibold" href="/servers">View Servers</a>
                <a className="px-5 py-3 rounded-md border border-white/10 text-white" href="/about">About</a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-12 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white/3 p-6 rounded-lg">
          <h3 className="text-xl font-semibold mb-2">Latest News</h3>
          <p className="text-sm text-white/80">Placeholder for latest clan announcements and updates.</p>
        </div>
        <div className="bg-white/3 p-6 rounded-lg">
          <h3 className="text-xl font-semibold mb-2">Featured Server</h3>
          <p className="text-sm text-white/80">Live server status and quick connect link.</p>
        </div>
        <div className="bg-white/3 p-6 rounded-lg">
          <h3 className="text-xl font-semibold mb-2">Join Us</h3>
          <p className="text-sm text-white/80">Recruitment details and Discord link.</p>
        </div>
      </div>
    </section>
  )
}
