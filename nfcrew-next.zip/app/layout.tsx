import './globals.css'
import React from 'react'

export const metadata = {
  title: 'NF.CREW',
  description: 'NF.CREW - Net Fraggers Crew'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#050606] text-white antialiased">
        <header className="border-b border-white/5">
          <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <img src="/images/nfcrew_Logo.png" alt="NF.CREW" className="h-12 w-auto"/>
              <h1 className="text-2xl font-bold">NF.CREW</h1>
            </div>
            <nav className="space-x-6">
              <a href="/" className="uppercase text-sm text-white/90">Home</a>
              <a href="/about" className="uppercase text-sm text-white/90">About</a>
              <a href="/servers" className="uppercase text-sm text-white/90">Servers</a>
              <a href="/forum" className="uppercase text-sm text-white/90">Forum</a>
            </nav>
          </div>
        </header>
        <main>{children}</main>
        <footer className="border-t border-white/5 mt-12">
          <div className="max-w-7xl mx-auto px-6 py-6 text-sm text-white/60">&copy; {new Date().getFullYear()} NF.CREW</div>
        </footer>
      </body>
    </html>
  )
}
